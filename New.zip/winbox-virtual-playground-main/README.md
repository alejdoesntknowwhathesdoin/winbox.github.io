testing windows emu 
