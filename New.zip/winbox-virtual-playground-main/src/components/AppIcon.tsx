interface AppIconProps {
  name: string;
  icon: string;
  action: () => void;
}

const AppIcon = ({ name, icon, action }: AppIconProps) => {
  return (
    <button
      onClick={action}
      className="group flex flex-col items-center justify-center p-2 rounded-lg hover:bg-app-hover active:bg-app-active transition-all duration-200 hover:animate-taskbar-bounce relative min-w-[48px]"
      title={name}
    >
      <div className="text-2xl mb-1 group-hover:scale-110 transition-transform duration-200">
        {icon}
      </div>
      
      {/* App Name */}
      <span className="text-xs text-text-secondary font-medium leading-none">
        {name}
      </span>
      
      {/* Active Indicator */}
      <div className="absolute bottom-0 w-1 h-1 bg-app-focus rounded-full opacity-0 group-hover:opacity-100 transition-opacity duration-200"></div>
    </button>
  );
};

export default AppIcon;