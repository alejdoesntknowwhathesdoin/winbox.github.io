import { useState, useEffect } from 'react';
import Taskbar from './Taskbar';
import WidgetPanel from './WidgetPanel';
import DesktopIcon from './DesktopIcon';
import Window from './Window';
import Calculator from './apps/Calculator';
import Notepad from './apps/Notepad';
import wallpaper from '@/assets/windows10-wallpaper.jpg';

interface OpenWindow {
  id: string;
  title: string;
  component: React.ReactNode;
  x: number;
  y: number;
}

const Desktop = () => {
  const [showWidgets, setShowWidgets] = useState(false);
  const [openWindows, setOpenWindows] = useState<OpenWindow[]>([]);

  const toggleWidgets = () => {
    setShowWidgets(!showWidgets);
  };

  const openWindow = (id: string, title: string, component: React.ReactNode) => {
    const existingWindow = openWindows.find(w => w.id === id);
    if (existingWindow) return; // Don't open duplicate windows

    const newWindow: OpenWindow = {
      id,
      title,
      component,
      x: 100 + openWindows.length * 30,
      y: 100 + openWindows.length * 30,
    };

    setOpenWindows(prev => [...prev, newWindow]);
  };

  const closeWindow = (id: string) => {
    setOpenWindows(prev => prev.filter(w => w.id !== id));
  };

  const websiteUrl = 'https://wildcard.vapor.my.cdn.cloudflare.net/scram.html';

  const desktopApps = [
    { 
      name: 'Calculator', 
      icon: '🧮', 
      action: () => openWindow('calculator', 'Calculator', <Calculator />),
      x: 50, 
      y: 50 
    },
    { 
      name: 'Notepad', 
      icon: '📝', 
      action: () => openWindow('notepad', 'Notepad', <Notepad />),
      x: 50, 
      y: 150 
    },
    { 
      name: 'Chrome', 
      icon: '🌐', 
      action: () => openWindow('chrome', 'Google Chrome', <iframe src={websiteUrl} className="w-full h-full" title="Chrome" />),
      x: 50, 
      y: 250 
    },
    { 
      name: 'Fortnite', 
      icon: '🎮', 
      action: () => openWindow('fortnite', 'Fortnite', <iframe src={websiteUrl} className="w-full h-full" title="Fortnite" />),
      x: 50, 
      y: 350 
    },
    { 
      name: 'Rainbow Six Siege', 
      icon: '🎯', 
      action: () => openWindow('r6', 'Rainbow Six Siege', <iframe src={websiteUrl} className="w-full h-full" title="Rainbow Six Siege" />),
      x: 50, 
      y: 450 
    },
    { 
      name: 'Rust', 
      icon: '⚙️', 
      action: () => openWindow('rust', 'Rust', <iframe src={websiteUrl} className="w-full h-full" title="Rust" />),
      x: 50, 
      y: 550 
    },
    { 
      name: 'YouTube', 
      icon: '▶️', 
      action: () => openWindow('youtube', 'YouTube', <iframe src={websiteUrl} className="w-full h-full" title="YouTube" />),
      x: 50, 
      y: 650 
    },
    { 
      name: 'Unturned', 
      icon: '🧟', 
      action: () => openWindow('unturned', 'Unturned', <iframe src={websiteUrl} className="w-full h-full" title="Unturned" />),
      x: 50, 
      y: 750 
    },
    { 
      name: 'BeamNG Drive', 
      icon: '🚗', 
      action: () => openWindow('beamng', 'BeamNG Drive', <iframe src={websiteUrl} className="w-full h-full" title="BeamNG Drive" />),
      x: 50, 
      y: 850 
    },
    { 
      name: 'Xbox Cloud Gaming', 
      icon: '🎮', 
      action: () => openWindow('xbox', 'Xbox Cloud Gaming', <iframe src={websiteUrl} className="w-full h-full" title="Xbox Cloud Gaming" />),
      x: 50, 
      y: 950 
    },
  ];

  return (
    <div 
      className="h-screen w-full bg-cover bg-center bg-no-repeat overflow-hidden relative"
      style={{ backgroundImage: `url(${wallpaper})` }}
    >
      {/* Desktop Area */}
      <div className="h-full w-full relative">
        
        {/* Desktop Icons */}
        {desktopApps.map((app, index) => (
          <DesktopIcon
            key={index}
            name={app.name}
            icon={app.icon}
            onOpen={app.action}
            x={app.x}
            y={app.y}
          />
        ))}

        {/* Open Windows */}
        {openWindows.map((window) => (
          <Window
            key={window.id}
            title={window.title}
            onClose={() => closeWindow(window.id)}
            initialX={window.x}
            initialY={window.y}
          >
            {window.component}
          </Window>
        ))}
        
        {/* Widget Panel */}
        <WidgetPanel isOpen={showWidgets} onClose={() => setShowWidgets(false)} />
        
        {/* Taskbar */}
        <Taskbar onWidgetsClick={toggleWidgets} />
      </div>
    </div>
  );
};

export default Desktop;
