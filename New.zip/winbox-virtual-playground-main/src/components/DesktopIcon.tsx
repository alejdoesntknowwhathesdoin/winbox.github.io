interface DesktopIconProps {
  name: string;
  icon: string;
  onOpen: () => void;
  x?: number;
  y?: number;
}

const DesktopIcon = ({ name, icon, onOpen, x = 0, y = 0 }: DesktopIconProps) => {
  return (
    <button
      onClick={onOpen}
      className="group flex flex-col items-center justify-center p-3 rounded-lg hover:bg-white/10 active:bg-white/20 transition-all duration-200 w-20 text-center"
      style={{ position: 'absolute', left: x, top: y }}
      title={name}
    >
      <div className="text-4xl mb-2 group-hover:scale-110 transition-transform duration-200 drop-shadow-lg">
        {icon}
      </div>
      
      {/* App Name */}
      <span className="text-xs text-white font-medium leading-tight drop-shadow-md px-1 py-0.5 rounded bg-black/20 backdrop-blur-sm">
        {name}
      </span>
    </button>
  );
};

export default DesktopIcon;
