import { useState, useEffect } from 'react';
import { Search, Folder, Settings, Wifi, Volume2, Battery } from 'lucide-react';
import AppIcon from './AppIcon';

interface TaskbarProps {
  onWidgetsClick: () => void;
}

const Taskbar = ({ onWidgetsClick }: TaskbarProps) => {
  const [currentTime, setCurrentTime] = useState(new Date());

  useEffect(() => {
    const timer = setInterval(() => {
      setCurrentTime(new Date());
    }, 1000);

    return () => clearInterval(timer);
  }, []);

  const formatTime = (date: Date) => {
    return date.toLocaleTimeString('en-US', {
      hour: 'numeric',
      minute: '2-digit',
      hour12: true
    });
  };

  const formatDate = (date: Date) => {
    return date.toLocaleDateString('en-US', {
      month: 'numeric',
      day: 'numeric',
      year: 'numeric'
    });
  };

  return (
    <div className="absolute bottom-0 left-0 right-0 h-12 bg-taskbar-bg-alpha backdrop-blur-xl border-t-2 border-taskbar-border flex items-center justify-between px-4 z-50">
      
      {/* Start Button */}
      <div className="flex items-center space-x-2">
        <button className="p-2 rounded-lg hover:bg-taskbar-hover transition-colors duration-200 flex items-center justify-center w-10 h-10">
          <div className="w-6 h-6 bg-gradient-to-br from-blue-500 to-purple-600 rounded-sm flex items-center justify-center text-white text-xs font-bold">
            ⊞
          </div>
        </button>
        
        {/* Search */}
        <button className="p-2 rounded-lg hover:bg-taskbar-hover transition-colors duration-200">
          <Search className="w-5 h-5 text-text-secondary" />
        </button>
        
        {/* Task View */}
        <button className="p-2 rounded-lg hover:bg-taskbar-hover transition-colors duration-200">
          <div className="w-5 h-5 border border-text-secondary rounded-sm relative">
            <div className="w-2 h-2 bg-text-secondary absolute top-0.5 left-0.5"></div>
            <div className="w-2 h-2 bg-text-secondary absolute top-0.5 right-0.5"></div>
            <div className="w-2 h-2 bg-text-secondary absolute bottom-0.5 left-0.5"></div>
            <div className="w-2 h-2 bg-text-secondary absolute bottom-0.5 right-0.5"></div>
          </div>
        </button>
        
        {/* Widgets Button */}
        <button 
          onClick={onWidgetsClick}
          className="p-2 rounded-lg hover:bg-taskbar-hover transition-colors duration-200"
        >
          <div className="w-5 h-5 grid grid-cols-2 gap-0.5">
            <div className="w-2 h-2 bg-text-secondary rounded-sm"></div>
            <div className="w-2 h-2 bg-text-secondary rounded-sm"></div>
            <div className="w-2 h-2 bg-text-secondary rounded-sm"></div>
            <div className="w-2 h-2 bg-text-secondary rounded-sm"></div>
          </div>
        </button>
      </div>

      {/* Center - Empty space for running apps */}
      <div className="flex-1"></div>

      {/* System Tray */}
      <div className="flex items-center space-x-2">
        {/* System Icons */}
        <div className="flex items-center space-x-1">
          <Wifi className="w-4 h-4 text-text-secondary" />
          <Volume2 className="w-4 h-4 text-text-secondary" />
          <Battery className="w-4 h-4 text-text-secondary" />
        </div>
        
        {/* Date & Time */}
        <button className="p-2 rounded-lg hover:bg-taskbar-hover transition-colors duration-200 text-right">
          <div className="text-sm font-medium text-text-primary leading-none">
            {formatTime(currentTime)}
          </div>
          <div className="text-xs text-text-secondary leading-none">
            {formatDate(currentTime)}
          </div>
        </button>
        
        {/* Notifications */}
        <button className="p-2 rounded-lg hover:bg-taskbar-hover transition-colors duration-200">
          <div className="w-5 h-5 border border-text-secondary rounded-sm flex items-center justify-center">
            <div className="w-2 h-2 bg-text-secondary rounded-full"></div>
          </div>
        </button>
      </div>
    </div>
  );
};

export default Taskbar;