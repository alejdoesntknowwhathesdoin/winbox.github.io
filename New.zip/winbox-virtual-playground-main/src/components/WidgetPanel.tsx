import { X, ExternalLink, Coffee, MessageCircle } from 'lucide-react';

interface WidgetPanelProps {
  isOpen: boolean;
  onClose: () => void;
}

const WidgetPanel = ({ isOpen, onClose }: WidgetPanelProps) => {
  if (!isOpen) return null;

  return (
    <div className="absolute top-0 right-0 w-80 h-full bg-widget-bg/95 backdrop-blur-xl border-l border-glass-border z-40 animate-widget-slide">
      
      {/* Header */}
      <div className="flex items-center justify-between p-4 border-b border-glass-border">
        <h2 className="text-lg font-semibold text-widget-text">Widgets</h2>
        <button
          onClick={onClose}
          className="p-2 rounded-lg hover:bg-white/10 transition-colors duration-200"
        >
          <X className="w-5 h-5 text-widget-text" />
        </button>
      </div>

      {/* Widget Content */}
      <div className="p-4 space-y-4">
        
        {/* Discord Widget */}
        <div className="bg-widget-bg/60 backdrop-blur-md rounded-xl p-4 border border-glass-border">
          <div className="flex items-center space-x-3 mb-3">
            <MessageCircle className="w-6 h-6 text-[#5865F2]" />
            <h3 className="text-widget-text font-semibold">Tips Help Us Stay Up</h3>
          </div>
          <p className="text-widget-text/80 text-sm mb-3">
            Connect with the community, get help, and share your builds!
          </p>
          <button
            onClick={() => window.open('https://buymeacoffee.com/alexistips', '_blank')}
            className="w-full bg-[#5865F2] hover:bg-[#4752c4] text-white px-4 py-2 rounded-lg transition-colors duration-200 flex items-center justify-center space-x-2"
          >
            <span>Join Discord</span>
            <ExternalLink className="w-4 h-4" />
          </button>
        </div>

        {/* Buy Me a Coffee Widget */}
        <div className="bg-widget-bg/60 backdrop-blur-md rounded-xl p-4 border border-glass-border">
          <div className="flex items-center space-x-3 mb-3">
            <Coffee className="w-6 h-6 text-[#FFDD00]" />
            <h3 className="text-widget-text font-semibold">Buy Me a Coffee</h3>
          </div>
          <p className="text-widget-text/80 text-sm mb-3">
            Support the development of this Windows 11 emulator!
          </p>
          <button
            onClick={() => window.open('https://buymeacoffee.com/alexistips', '_blank')}
            className="w-full bg-[#FFDD00] hover:bg-[#e6c600] text-black px-4 py-2 rounded-lg transition-colors duration-200 flex items-center justify-center space-x-2 font-medium"
          >
            <span>Buy Me a Coffee</span>
            <ExternalLink className="w-4 h-4" />
          </button>
        </div>

        {/* Weather Widget (Mock) */}
        <div className="bg-widget-bg/60 backdrop-blur-md rounded-xl p-4 border border-glass-border">
          <h3 className="text-widget-text font-semibold mb-2">Weather</h3>
          <div className="flex items-center justify-between">
            <div>
              <div className="text-2xl text-widget-text">☀️</div>
              <div className="text-widget-text/80 text-sm">Sunny</div>
            </div>
            <div className="text-right">
              <div className="text-2xl font-bold text-widget-text">72°F</div>
              <div className="text-widget-text/80 text-sm">San Francisco</div>
            </div>
          </div>
        </div>

        {/* Calendar Widget (Mock) */}
        <div className="bg-widget-bg/60 backdrop-blur-md rounded-xl p-4 border border-glass-border">
          <h3 className="text-widget-text font-semibold mb-2">Calendar</h3>
          <div className="text-widget-text/80 text-sm">
            <div className="mb-2">
              <div className="font-medium">Today</div>
              <div>No events scheduled</div>
            </div>
            <div>
              <div className="font-medium">Tomorrow</div>
              <div>Windows 11 Demo - 2:00 PM</div>
            </div>
          </div>
        </div>

      </div>
    </div>
  );
};

export default WidgetPanel;
