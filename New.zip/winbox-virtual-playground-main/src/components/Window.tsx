import { useState, useEffect } from 'react';
import { X, Minimize2, Maximize2, Minus } from 'lucide-react';

interface WindowProps {
  title: string;
  children: React.ReactNode;
  onClose: () => void;
  onMinimize?: () => void;
  initialX?: number;
  initialY?: number;
  width?: number;
  height?: number;
}

const Window = ({ 
  title, 
  children, 
  onClose, 
  onMinimize,
  initialX = 100, 
  initialY = 100,
  width = 600,
  height = 400 
}: WindowProps) => {
  const [position, setPosition] = useState({ x: initialX, y: initialY });
  const [size, setSize] = useState({ width, height });
  const [isMaximized, setIsMaximized] = useState(false);
  const [restorePosition, setRestorePosition] = useState({ x: initialX, y: initialY });
  const [restoreSize, setRestoreSize] = useState({ width, height });
  const [startData, setStartData] = useState<{ mouseX: number; mouseY: number; posX: number; posY: number; width: number; height: number } | null>(null);
  const [direction, setDirection] = useState<string>('');

  const minWidth = 300;
  const minHeight = 200;
  const taskbarHeight = 48; // Matches h-12 in Tailwind (3rem = 48px)

  useEffect(() => {
    const handleMove = (e: MouseEvent) => {
      if (!startData) return;

      const deltaX = e.clientX - startData.mouseX;
      const deltaY = e.clientY - startData.mouseY;

      if (direction === 'drag') {
        setPosition({
          x: startData.posX + deltaX,
          y: startData.posY + deltaY,
        });
      } else {
        let newX = startData.posX;
        let newY = startData.posY;
        let newWidth = startData.width;
        let newHeight = startData.height;

        if (direction.includes('left')) {
          newX = startData.posX + deltaX;
          newWidth = startData.width - deltaX;
        }
        if (direction.includes('right')) {
          newWidth = startData.width + deltaX;
        }
        if (direction.includes('top')) {
          newY = startData.posY + deltaY;
          newHeight = startData.height - deltaY;
        }
        if (direction.includes('bottom')) {
          newHeight = startData.height + deltaY;
        }

        newWidth = Math.max(newWidth, minWidth);
        newHeight = Math.max(newHeight, minHeight);

        if (newWidth === minWidth && direction.includes('left')) {
          newX = startData.posX + (startData.width - minWidth);
        }
        if (newHeight === minHeight && direction.includes('top')) {
          newY = startData.posY + (startData.height - minHeight);
        }

        setPosition({ x: newX, y: newY });
        setSize({ width: newWidth, height: newHeight });
      }
    };

    const handleUp = () => {
      setStartData(null);
      setDirection('');
    };

    document.addEventListener('mousemove', handleMove);
    document.addEventListener('mouseup', handleUp);

    return () => {
      document.removeEventListener('mousemove', handleMove);
      document.removeEventListener('mouseup', handleUp);
    };
  }, [startData, direction]);

  const handleDragStart = (e: React.MouseEvent) => {
    if (isMaximized) return;
    e.preventDefault();
    setDirection('drag');
    setStartData({
      mouseX: e.clientX,
      mouseY: e.clientY,
      posX: position.x,
      posY: position.y,
      width: size.width,
      height: size.height,
    });
  };

  const handleResizeStart = (e: React.MouseEvent, dir: string) => {
    if (isMaximized) return;
    e.preventDefault();
    e.stopPropagation();
    setDirection(dir);
    setStartData({
      mouseX: e.clientX,
      mouseY: e.clientY,
      posX: position.x,
      posY: position.y,
      width: size.width,
      height: size.height,
    });
  };

  const handleMaximize = () => {
    if (isMaximized) {
      setPosition(restorePosition);
      setSize(restoreSize);
      setIsMaximized(false);
    } else {
      setRestorePosition(position);
      setRestoreSize(size);
      setPosition({ x: 0, y: 0 });
      setSize({ width: window.innerWidth, height: window.innerHeight - taskbarHeight });
      setIsMaximized(true);
    }
  };

  return (
    <div
      className={`absolute bg-white border border-gray-300 overflow-hidden animate-window-slide-up z-30 ${isMaximized ? 'rounded-none' : 'rounded-lg shadow-2xl'}`}
      style={{
        left: `${position.x}px`,
        top: `${position.y}px`,
        width: `${size.width}px`,
        height: `${size.height}px`,
      }}
    >
      {/* Title Bar */}
      <div
        className="bg-gradient-to-r from-blue-600 to-blue-700 text-white px-4 py-2 flex items-center justify-between select-none"
        onMouseDown={handleDragStart}
        style={{ cursor: isMaximized ? 'default' : 'move' }}
      >
        <div className="flex items-center space-x-2">
          <div className="w-4 h-4 bg-white/20 rounded-sm"></div>
          <span className="font-medium text-sm">{title}</span>
        </div>
        
        <div className="flex items-center space-x-1">
          {onMinimize && (
            <button
              onClick={onMinimize}
              className="p-1 hover:bg-white/20 rounded transition-colors duration-200"
            >
              <Minus className="w-4 h-4" />
            </button>
          )}
          <button 
            onClick={handleMaximize}
            className="p-1 hover:bg-white/20 rounded transition-colors duration-200"
          >
            {isMaximized ? <Minimize2 className="w-4 h-4" /> : <Maximize2 className="w-4 h-4" />}
          </button>
          <button
            onClick={onClose}
            className="p-1 hover:bg-red-500 rounded transition-colors duration-200"
          >
            <X className="w-4 h-4" />
          </button>
        </div>
      </div>

      {/* Window Content */}
      <div 
        className="w-full h-[calc(100%-32px)] overflow-auto bg-white"
        style={{ contain: 'strict' }}
      >
        {children}
      </div>

      {/* Resize Handles */}
      {!isMaximized && (
        <>
          <div className="absolute top-0 left-0 w-full h-2 -mt-1 cursor-ns-resize" onMouseDown={(e) => handleResizeStart(e, 'top')} />
          <div className="absolute bottom-0 left-0 w-full h-2 -mb-1 cursor-ns-resize" onMouseDown={(e) => handleResizeStart(e, 'bottom')} />
          <div className="absolute left-0 top-0 h-full w-2 -ml-1 cursor-ew-resize" onMouseDown={(e) => handleResizeStart(e, 'left')} />
          <div className="absolute right-0 top-0 h-full w-2 -mr-1 cursor-ew-resize" onMouseDown={(e) => handleResizeStart(e, 'right')} />
          <div className="absolute top-0 left-0 w-3 h-3 -mt-1 -ml-1 cursor-nwse-resize" onMouseDown={(e) => handleResizeStart(e, 'top-left')} />
          <div className="absolute top-0 right-0 w-3 h-3 -mt-1 -mr-1 cursor-nesw-resize" onMouseDown={(e) => handleResizeStart(e, 'top-right')} />
          <div className="absolute bottom-0 left-0 w-3 h-3 -mb-1 -ml-1 cursor-nesw-resize" onMouseDown={(e) => handleResizeStart(e, 'bottom-left')} />
          <div className="absolute bottom-0 right-0 w-3 h-3 -mb-1 -mr-1 cursor-nwse-resize" onMouseDown={(e) => handleResizeStart(e, 'bottom-right')} />
        </>
      )}
    </div>
  );
};

export default Window;
