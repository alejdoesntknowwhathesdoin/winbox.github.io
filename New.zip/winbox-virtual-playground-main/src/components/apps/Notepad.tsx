import { useState } from 'react';

const Notepad = () => {
  const [text, setText] = useState('');

  return (
    <div className="h-full flex flex-col">
      {/* Menu Bar */}
      <div className="bg-gray-100 border-b border-gray-300 px-2 py-1">
        <div className="flex space-x-4 text-sm">
          <button className="hover:bg-gray-200 px-2 py-1 rounded">File</button>
          <button className="hover:bg-gray-200 px-2 py-1 rounded">Edit</button>
          <button className="hover:bg-gray-200 px-2 py-1 rounded">Format</button>
          <button className="hover:bg-gray-200 px-2 py-1 rounded">View</button>
          <button className="hover:bg-gray-200 px-2 py-1 rounded">Help</button>
        </div>
      </div>

      {/* Text Area */}
      <textarea
        value={text}
        onChange={(e) => setText(e.target.value)}
        className="flex-1 p-4 font-mono text-sm resize-none outline-none border-none"
        placeholder="Start typing..."
        spellCheck={false}
      />

      {/* Status Bar */}
      <div className="bg-gray-100 border-t border-gray-300 px-4 py-1 text-xs text-gray-600 flex justify-between">
        <span>Ln {text.split('\n').length}, Col {text.length - text.lastIndexOf('\n')}</span>
        <span>Windows (CRLF) | UTF-8</span>
      </div>
    </div>
  );
};

export default Notepad;