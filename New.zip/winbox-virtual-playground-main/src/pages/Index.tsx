import Desktop from '@/components/Desktop';

const Index = () => {
  return <Desktop />;
};

export default Index;
